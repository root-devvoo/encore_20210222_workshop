package servlet.form;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ID = request.getParameter("ID");
		String PASSWORD = request.getParameter("PASSWORD");
		
		PrintWriter out = response.getWriter();
		out.println("<html><body><h4><center>");
		out.println(ID+" Login!!!</h4><br><br></center>");
		out.println("<a href=url><center>Register Book</center></a><br>");
		out.println("<a href=http://localhost:8888/Workshop01/login.html><center>Logout</center></a>");
		out.println("</body></html>");
	}

}
